# Questão 3

Created: May 21, 2021 11:18 AM
Tags: Dúvida, Revisar

## Letra a-

- Considerando o fato de que estava aberta a muito tempo, podemos afirmar que os capacitores estavam carregados $\therefore$ Não estava passando corrente por eles. Tal afirmação sobre as correntes nos capacitores (e por conseguinte em suas malhas) indica que as $DDP$ são iguais as da fonte, isso é, $50V$

## Letra b-

- Sabemos ainda que por não estar passando corrente nos capacitores eles precisam ter $DDP$ igual da fonte, logo a corrente que passa na fonte também é $0A$

![Simulação só para make sure](Questa%CC%83o%203%20c4fbcbd2e8434bbaa945f4347a0ba086/Screen_Shot_2021-05-21_at_8.01.38_PM.png)

Simulação só para make sure

## Letra c-

$$
i = 5 - (0.2)(50)(-0.66)^{-1}e^{-\frac{t}{0.66}}
$$