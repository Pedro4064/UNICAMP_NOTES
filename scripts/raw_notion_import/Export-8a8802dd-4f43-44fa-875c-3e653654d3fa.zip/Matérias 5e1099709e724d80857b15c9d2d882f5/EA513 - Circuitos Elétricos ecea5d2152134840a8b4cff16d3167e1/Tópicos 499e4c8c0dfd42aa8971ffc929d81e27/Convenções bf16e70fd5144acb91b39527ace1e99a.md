# Convenções

Aula: Aula 1
Created: March 18, 2021 9:05 PM
Prova: P1

## Corrente

- A corrente flui do maior potencial para o menor potencial. Movimento das "Cargas positivas", sentido inverso da corrente eletrônica (corrente de elétrons).

## DDP

- A diferença de potencial (d.d.p.) entre dois pontos **a** e **b**, pode ser expressa por $Va - Vb$ ou, simplesmente, $Vab$, sendo **a** um ponto de maior potencial que **b.**

![Convenc%CC%A7o%CC%83es%20bf16e70fd5144acb91b39527ace1e99a/Screen_Shot_2021-03-18_at_9.53.29_PM.png](Convenc%CC%A7o%CC%83es%20bf16e70fd5144acb91b39527ace1e99a/Screen_Shot_2021-03-18_at_9.53.29_PM.png)

## Bipolos

- A corrente entra em bipolos passivos. A corrente sai de bipolos ativos.

![Convenc%CC%A7o%CC%83es%20bf16e70fd5144acb91b39527ace1e99a/Screen_Shot_2021-03-18_at_9.56.01_PM.png](Convenc%CC%A7o%CC%83es%20bf16e70fd5144acb91b39527ace1e99a/Screen_Shot_2021-03-18_at_9.56.01_PM.png)