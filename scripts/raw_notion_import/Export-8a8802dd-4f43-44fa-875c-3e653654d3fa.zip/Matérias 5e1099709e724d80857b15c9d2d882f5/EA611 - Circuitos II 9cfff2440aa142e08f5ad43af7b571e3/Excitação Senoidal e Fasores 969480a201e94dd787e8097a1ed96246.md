# Excitação Senoidal e Fasores

[Anotações de Aula](Excitac%CC%A7a%CC%83o%20Senoidal%20e%20Fasores%20969480a201e94dd787e8097a1ed96246/Anotac%CC%A7o%CC%83es%20de%20Aula%203bb1a77a06ff47e8a4e20aac218fa828.md)

- SUMMARY
    
    

# Introdução

$\hookrightarrow$ O principal objeto de estudos em circuitos II será circuitos com excitação senoidal, i.e circuitos de corrente alternada (AC).

$\hookrightarrow$ No geral existem 3 possíveis métodos para abordar problemas de excitação senoidal:

1. **EDO** → Fazemos o equacionamento normal do circuito e resolvemos a EDO, o que pode se tornar extremamente difícil dependendo do tamanho do circuito
2. **Laplace** → Laplace nós transformamos o circuito (e os elementos nele) para o plano $s$ de Laplace, e o equacionamento antes de equações diferencias se tornam problemas simples de algebra no domínio da frequência, para então fazermos a anti-transformada e acharmos a equação no domínio do tempo.
3. **Fasores** → Para fasores nós também transformamos o circuito para o domínio dos números complexos,  considerando somente a magnitude e o phase-shift do circuito, o que também torna o problema puramente algébrico. Em fasores, entretanto, o circuito está em steady-state, e não podemos analizar o comportamento transiente.

# Excitação Senoidal

$\hookrightarrow$ A excitação senoidal tem, de modo geral, o seguinte formato:

$$
v(t) = V_m \sin(\omega t)
$$

$\hookrightarrow$ Onde:

- $V_m$ : Máxima tensão, chamada de amplitude do sinal
- $\omega$    : Frequência de oscilação da tensão

$\hookrightarrow$ Além disso, temos alguns conceitos que são de suma importância de serem entendidos para a análise de excitações senoidais:

## **Período**

- Definido como sendo o intervalo de tempo necessário para o sinal completar um ciclo:
    
    $$
    \omega T = 2 \pi \Rightarrow T = \frac{2 \pi}{\omega}
    $$
    

## Frequência

- A frequência é definida como o número de ciclos por segundo, logo temos que a frequência é o inverso do período:

$$
f = \frac{1}{T}
$$

## Fase

- A fase $\phi$ indica a defasagem de um sinal senoidal $v(t)$ em relação à função senoidal usual (fase nula).
- Quando estamos falando de fase, normalmente nós falamos se uma onda em análise está “adiantada” ou “atrasada”. Isso se refere se a função atinge zero antes de $t = 0$ (sendo adiantada) ou depois, para $t > 0$ ( sendo atrasada)
- Considerando uma função:

$$
v(t) = V_m \sin (\omega t + \varphi)
$$

- Como é uma função senoidal, temos:
    
    $$
    sin(\alpha) = 0 \iff \alpha = [0, \pi]
    $$
    
- Logo, igualamos o que está dentro do $\sin$ a zero e vemos se o tempo vai dar positivo ( atrasada) ou negativo (adianta):
    
    $$
    \omega t + \varphi = 0 \Rightarrow t = - \frac{\varphi}{\omega}, \ Adiantada
    $$
    

# Fasores

## Introdução

$\hookrightarrow$ Como dito anteriormente, o uso de fasores é para análise em regime permanente do circuito senoidal. 

$\hookrightarrow$ Para tal, as variáveis que queremos saber é a magnitude da tensão/corrente e a fase em relação ao sinal de entrada. Se observarmos bem a frequência não foi listada, pois ela se matem constante em todo o circuito, podendo haver somente diferentes magnitudes e phase-shifts.

$\hookrightarrow$ O fasor tem o seguinte formato:

$$
\alpha \phase{\phi}
$$

$\hookrightarrow$ Onde:

- $\alpha$ : A magnitude do sinal.
- $\phi$  : A fase do sinal, em graus.

$\hookrightarrow$ Relembrando que fasor nada mais é do que a representação polar de números complexos.

## Circuito Transformado

$\hookrightarrow$ Para analisarmos o circuito utilizando fasores, nós precisamos transformar os seus componentes também para fasores:

### Resistor

- Para resistores não há diferença

### Capacitor

- Para capacitores temos:
    
    $$
    \underline{V_c} = \frac{1}{j\omega C} \underline{I_c}
    $$
    

### Indutor

- Para indutores temos:

$$
\underline{V_L} = j \omega L\underline {I_L}
$$

## Impedâncias

### Definição

$\hookrightarrow$ Definimos a impedância $Z$ como sendo a relação da tensão fasorial pela corrente fasorial:

$$
Z = \frac{\underline {V_m}}{\underline {I_m}} = \frac{V_m}{I_m} \phase{\theta - \phi}
$$

$\hookrightarrow$ Relembrando que quando dividimos fasores (ou seja números complexos no formato polar) nós dividimos as magnitudes e subtraímos as fases.

$\hookrightarrow$ Como dito anteiormente, fasores são nada mais que números complexos, logo podemos representá-los no formato retangular:

$$
Z = R + j X
$$

$\hookrightarrow$ Onde:

- $R$ : Representa a impedância resistiva
- $X$ : Representa a Reatância (impedância reativa)

### Associação de Impedâncias

$\hookrightarrow$ Algo muito bom ao utilizarmos fasores, é que podemos associar as impedâncias de diferentes tipos de dispositivos (capacitores, resistores e inductores) e achar uma única impedância equivalente.

$\hookrightarrow$ O calculo de impedância equivalente segue o mesmo formato do calculo de rsistência equivalente:

- **Série**

$$
Z_{eq} = Z_1 + Z_2 + ...+Z_n
$$

- **Paralelo**

$$
Z_{eq} = \left[ \frac{1}{Z_1} + \frac{1}{Z_2} + ...+\frac{1}{Z_n}\right]^{-1}
$$

## Potência

### Potência Média

$\hookrightarrow$ Considerando o caso de um circuito impedância não puramente resistiva temos que a potência média é dada por:

$$
\bar p = \frac{V_m I_m}{2}\cos \theta
$$

$\hookrightarrow$ Onde:

- $V_m$ : Magnitude da tensão
- $I_m$  : Magnitude da corrente
- $\theta$     : Fase devido à carga*

$\hookrightarrow$ Para acharmos a fase devido à carga precisamos calcular a impedância equivalente e, posteriormente, transformar $Z_{eq}$ da forma retangular para a forma polar. Para tal é mais fácil pensar no plano onde no eixo $Y$ estão os imaginários e no eixo $X$ os reais, e fazer pitágoras para achar a magnitude (que é a hipotenusa) e o ângulo (que é o $\theta$).

### Valores Eficazes

$\hookrightarrow$ Chamamos de valor eficaz de uma  corrente periódica o valor equivalente de uma corrente contínua que entrega a mesma potência para um resistor.

$\hookrightarrow$ É dada por:

$$
I_{ef} = \frac{I_m}{\sqrt 2}
$$

$\hookrightarrow$ De forma equivalente temos a tensão equivalente:

$$
V_{ef} = \frac{V_m}{\sqrt 2}
$$

$\hookrightarrow$ A partir disso podemos calcular o valor da potência média utilizando os valores eficazes:

$$
\bar p = I_{ef} V_{ef} \cos \theta
$$

### **Fator de Potência**

$\hookrightarrow$ Chamamos de fator de potência $(f_p)$ a relação entre a potência média e a potência aparente:

$$
f_p = \frac{\bar p}{I_{ef} V_{ef}} = \cos \theta
$$

$\hookrightarrow$ Relembrando que $\theta$ é a fase da carga.

$\hookrightarrow$ É importante que o fator de potência seja o maior possível, pois significa que há pouco necessidade de transmissão de potência reativa, que é de perda mais fácil durante o transporte. Além disso quanto maior o fator de potência consome-se menos potência aparente.

$\hookrightarrow$ Devido a tais benefícios, é comum a instalação de banco de capacitores (que possui uma fase negativa, logo diminui a fase total do circuito) em paralelo com plantas muito indutivas, para diminuir o $\theta$ e aumentar o fator de potência.

$\hookrightarrow$ A fórmula para a impedância capacitiva que precisa ser acrescentada em paralelo para se atingir um fator de potência $f_p$ desejado é:

$$
X_1 = \frac{R^2 + X^2}{R \cdot \tg(\cos^{-1} f_p) - X} \Rightarrow C = -\frac{1}{\omega X_1}
$$

$\hookrightarrow$ Onde:

- $R$ → Parte real da impedância equivalente atual do circuito
- $X$ → Parte imaginária da impedância equivalente atual do circuito
- $f_p$ → Fator de potência alvo
- $X_1$→ Parte imaginária alvo
- $C$  → Capacitor alvo