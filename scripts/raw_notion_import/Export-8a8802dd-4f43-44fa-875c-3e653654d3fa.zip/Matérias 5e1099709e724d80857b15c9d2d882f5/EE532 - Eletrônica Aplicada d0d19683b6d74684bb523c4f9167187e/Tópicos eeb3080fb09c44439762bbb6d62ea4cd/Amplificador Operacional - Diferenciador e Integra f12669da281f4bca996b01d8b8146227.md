# Amplificador Operacional - Diferenciador e Integrador

Created: June 22, 2022 10:35 AM
Prova: P4

- SUMMARY

# Topologias

## Integrador

![Screen Shot 2022-06-22 at 10.36.27 AM.png](Amplificador%20Operacional%20-%20Diferenciador%20e%20Integra%20f12669da281f4bca996b01d8b8146227/Screen_Shot_2022-06-22_at_10.36.27_AM.png)

![Screen Shot 2022-06-22 at 10.36.44 AM.png](Amplificador%20Operacional%20-%20Diferenciador%20e%20Integra%20f12669da281f4bca996b01d8b8146227/Screen_Shot_2022-06-22_at_10.36.44_AM.png)

## Diferenciador

![Screen Shot 2022-06-22 at 10.37.54 AM.png](Amplificador%20Operacional%20-%20Diferenciador%20e%20Integra%20f12669da281f4bca996b01d8b8146227/Screen_Shot_2022-06-22_at_10.37.54_AM.png)

![Screen Shot 2022-06-22 at 10.38.14 AM.png](Amplificador%20Operacional%20-%20Diferenciador%20e%20Integra%20f12669da281f4bca996b01d8b8146227/Screen_Shot_2022-06-22_at_10.38.14_AM.png)