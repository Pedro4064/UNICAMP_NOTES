# Amplificador Operacional - Subtrator

Created: June 8, 2022 4:24 PM
Prova: P4

![Screen Shot 2022-06-08 at 4.28.28 PM.png](Amplificador%20Operacional%20-%20Subtrator%2039e799c79c8849a69afb0f9c28268e14/Screen_Shot_2022-06-08_at_4.28.28_PM.png)

![Screen Shot 2022-06-22 at 9.19.05 AM.png](Amplificador%20Operacional%20-%20Subtrator%2039e799c79c8849a69afb0f9c28268e14/Screen_Shot_2022-06-22_at_9.19.05_AM.png)

<aside>
<img src="Amplificador%20Operacional%20-%20Subtrator%2039e799c79c8849a69afb0f9c28268e14/Evangelion.gif" alt="Amplificador%20Operacional%20-%20Subtrator%2039e799c79c8849a69afb0f9c28268e14/Evangelion.gif" width="40px" /> O principal problema dessa topologia, principalmente quando formos falar de instrumentação, é que a impedância de entrada não tende mais a infinito mas sim a $2R_1$, o que significa que $i_f \ne 0$ (o que não é desejado para instrumentação)

</aside>