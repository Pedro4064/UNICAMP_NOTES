# Amplificador Operacional - [Não Idealidade] Tensão de Offset

Created: June 24, 2022 3:11 PM
Prova: P4

- SUMMARY

# Introdução

$\hookrightarrow$ Devido a construção do OpAmp, há na verdade um offset de tensão, tanto na entrada quanto na saída, os quais serão abordados nessa aula.

# Tensão de Offset

## Entrada

![Screen Shot 2022-06-24 at 3.13.30 PM.png](Amplificador%20Operacional%20-%20%5BNa%CC%83o%20Idealidade%5D%20Tensa%201c6dde1f12394016ae1388c1e8e4292f/Screen_Shot_2022-06-24_at_3.13.30_PM.png)