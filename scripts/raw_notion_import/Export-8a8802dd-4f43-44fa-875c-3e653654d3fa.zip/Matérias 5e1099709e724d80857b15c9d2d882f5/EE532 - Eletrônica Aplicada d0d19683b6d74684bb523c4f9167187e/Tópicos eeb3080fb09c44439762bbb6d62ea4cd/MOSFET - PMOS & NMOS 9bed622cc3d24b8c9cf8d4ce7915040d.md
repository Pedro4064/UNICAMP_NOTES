# MOSFET - PMOS & NMOS

Created: May 11, 2022 4:47 PM
Prova: P3

- SUMMARY

# Tipos de MOSFET

$\hookrightarrow$ Temos dois possíveis tipos de MOSFETs, sendo eles:

## PMOS

![Screen Shot 2022-05-11 at 4.48.40 PM.png](MOSFET%20-%20PMOS%20&%20NMOS%209bed622cc3d24b8c9cf8d4ce7915040d/Screen_Shot_2022-05-11_at_4.48.40_PM.png)

![Screen Shot 2022-05-11 at 4.48.55 PM.png](MOSFET%20-%20PMOS%20&%20NMOS%209bed622cc3d24b8c9cf8d4ce7915040d/Screen_Shot_2022-05-11_at_4.48.55_PM.png)

## NMOS

![Screen Shot 2022-05-11 at 4.56.43 PM.png](MOSFET%20-%20PMOS%20&%20NMOS%209bed622cc3d24b8c9cf8d4ce7915040d/Screen_Shot_2022-05-11_at_4.56.43_PM.png)