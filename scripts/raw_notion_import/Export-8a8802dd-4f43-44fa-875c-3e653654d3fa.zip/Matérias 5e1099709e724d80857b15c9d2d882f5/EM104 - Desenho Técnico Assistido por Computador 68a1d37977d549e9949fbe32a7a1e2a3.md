# EM104 - Desenho Técnico Assistido por Computador

Created: September 15, 2020 5:22 PM
Instituto: FEM
Semestre: 2º Semestre

## Introdução

- Dar os primeiros passos na leitura e interpretação de um desenho técnico.
- Tópicos que serão abordados:

![EM104%20-%20Desenho%20Te%CC%81cnico%20Assistido%20por%20Computador%2068a1d37977d549e9949fbe32a7a1e2a3/Screen_Shot_2020-09-24_at_9.30.25_PM.png](EM104%20-%20Desenho%20Te%CC%81cnico%20Assistido%20por%20Computador%2068a1d37977d549e9949fbe32a7a1e2a3/Screen_Shot_2020-09-24_at_9.30.25_PM.png)

## Convenção

- Ao lado direito da imagem frontal está a visão lateral esquerda, na esquerda da visão frontal está posicionado a visão lateral direita, embaixo da visão frontal está a visão superior

![EM104%20-%20Desenho%20Te%CC%81cnico%20Assistido%20por%20Computador%2068a1d37977d549e9949fbe32a7a1e2a3/Screen_Shot_2020-09-24_at_9.40.11_PM.png](EM104%20-%20Desenho%20Te%CC%81cnico%20Assistido%20por%20Computador%2068a1d37977d549e9949fbe32a7a1e2a3/Screen_Shot_2020-09-24_at_9.40.11_PM.png)

Ex ate a pagina 7, ler ate 48