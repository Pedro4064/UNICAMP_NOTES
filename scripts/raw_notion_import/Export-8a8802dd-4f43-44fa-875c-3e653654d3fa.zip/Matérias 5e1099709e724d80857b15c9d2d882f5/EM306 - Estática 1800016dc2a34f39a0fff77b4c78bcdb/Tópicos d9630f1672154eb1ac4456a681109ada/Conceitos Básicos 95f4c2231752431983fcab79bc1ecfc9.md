# Conceitos Básicos

Aula: Aula02
Capítulo: Cap. 1
Created: August 9, 2021 9:28 PM
Prova: P1

[Anotações de Aula](Conceitos%20Ba%CC%81sicos%2095f4c2231752431983fcab79bc1ecfc9/Anotac%CC%A7o%CC%83es%20de%20Aula%2044e4ef145f8e4f5cadea78356a776a90.md)