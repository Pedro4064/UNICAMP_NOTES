# Equilíbrio De Um Corpo Rígido - 3 dimensões

Capítulo: Cap. 5
Created: September 30, 2021 10:10 AM
Prova: P1

- SUMÁRIO

# Apoios

$\hookrightarrow$ De forma análoga a como havia em questões bidimensionais, em problemas tridimensionais também temos catalogados as reações nas peças para diferentes tipos de ligação e apoios:

- TABELA DE APOIOS
    
    ![Screen Shot 2021-09-30 at 6.09.11 PM.png](Equili%CC%81brio%20De%20Um%20Corpo%20Ri%CC%81gido%20-%203%20dimenso%CC%83es%2080a3ffc2432e426dbf7645d26bdcb224/Screen_Shot_2021-09-30_at_6.09.11_PM.png)
    
    ![Screen Shot 2021-09-30 at 6.09.37 PM.png](Equili%CC%81brio%20De%20Um%20Corpo%20Ri%CC%81gido%20-%203%20dimenso%CC%83es%2080a3ffc2432e426dbf7645d26bdcb224/Screen_Shot_2021-09-30_at_6.09.37_PM.png)
    
    ![Screen Shot 2021-09-30 at 6.09.51 PM.png](Equili%CC%81brio%20De%20Um%20Corpo%20Ri%CC%81gido%20-%203%20dimenso%CC%83es%2080a3ffc2432e426dbf7645d26bdcb224/Screen_Shot_2021-09-30_at_6.09.51_PM.png)