# Anotações de Aula

# Quantidades

## Vetores

- Quantidades que apresentam intensidade e direção, como:
    1. Forças
    2. Deslocamento
    3. Velocidade
    4. Aceleração 
- Apresenta os seguintes componentes:
    
    $\hookrightarrow$ Módulo: Escalar
    
    $\hookrightarrow$ Direção: Relação do vetor com o frame of reference (no nosso caso o espaço cartesiano).
    
    $\hookrightarrow$ Sentido:
    

## Escalares

- Quantidades com somente "intensidade" $\therefore$ independem da direção (não existe), é somente uma representação numérica.
    1. Temperatura
    2. Massa
    3. Tempo