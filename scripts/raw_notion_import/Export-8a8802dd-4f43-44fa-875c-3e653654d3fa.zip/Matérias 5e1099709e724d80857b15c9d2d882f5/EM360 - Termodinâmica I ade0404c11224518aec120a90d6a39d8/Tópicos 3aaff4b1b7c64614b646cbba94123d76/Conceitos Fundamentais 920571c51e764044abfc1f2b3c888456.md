# Conceitos Fundamentais

Aula: Aula02
Created: August 9, 2021 9:27 PM

[Anotações de Aula](Conceitos%20Fundamentais%20920571c51e764044abfc1f2b3c888456/Anotac%CC%A7o%CC%83es%20de%20Aula%20ad173c8c151f4ee6a783f324e97b6403.md)