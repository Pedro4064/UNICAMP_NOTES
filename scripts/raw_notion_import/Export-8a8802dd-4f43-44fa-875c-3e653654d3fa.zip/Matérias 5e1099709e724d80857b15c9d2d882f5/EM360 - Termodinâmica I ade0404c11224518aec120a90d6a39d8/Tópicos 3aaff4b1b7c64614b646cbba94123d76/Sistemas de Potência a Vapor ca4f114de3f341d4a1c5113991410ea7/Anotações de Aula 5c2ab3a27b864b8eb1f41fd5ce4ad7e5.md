# Anotações de Aula

- SUMÁRIO
    
    

# Ciclo de Potência a Vapor

$\hookrightarrow$ Um dos mais notórios seria o ciclo de Rankine, composto por uma caldeira, turbina, condensador e bomba:

![Screen Shot 2021-10-08 at 9.10.40 PM.png](Anotac%CC%A7o%CC%83es%20de%20Aula%205c2ab3a27b864b8eb1f41fd5ce4ad7e5/Screen_Shot_2021-10-08_at_9.10.40_PM.png)