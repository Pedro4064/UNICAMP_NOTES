# Anotações de Aula

- SUMÁRIO

# O que é Entropia?

- Pode ser considerado como uma desorganização do sistema.
- Também é dita como a razão entre o delta de calor pelo tempo, dado por:

$$
ds = \frac{\delta Q}{T} \rightarrow s_2 - s_1 = \int^2_1 \frac{\delta Q}{t}
$$

- Para sistemas internamente reversíveis.
- Com isso podemos observar que entropia é uma PROPRIEDADE TERMODINÂMICA, logo o caminho não importa, podemos fazer a integral entre dois estados.
- Como temos a entropia como uma propriedade termodinâmica, podemos determina-la se tivermos duas propriedades independentes.