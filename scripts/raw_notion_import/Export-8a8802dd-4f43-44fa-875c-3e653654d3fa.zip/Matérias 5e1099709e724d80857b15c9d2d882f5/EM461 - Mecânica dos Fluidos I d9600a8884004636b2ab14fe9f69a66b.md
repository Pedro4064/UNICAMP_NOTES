# EM461 - Mecânica dos Fluidos I

Created: March 15, 2022 4:22 PM
Instituto: FEM
Semestre: 5º Semestre

[Tópicos](EM461%20-%20Meca%CC%82nica%20dos%20Fluidos%20I%20d9600a8884004636b2ab14fe9f69a66b/To%CC%81picos%20bbd6bfc39459438087b5b99bdb1c2396.csv)

# Dúvidas

→ Questão 2.56: Não deveriamos somar a força necessária do fluido 1 chegar a $V_i$ e depois somar a força necessária para chegar a $V$ o fluido final ?