# Conceitos Fundamentais

Cap: Cap. 2
Created: March 15, 2022 4:24 PM
Prova: P1

- SUMMARY

# Fluido como um Continuo

$\hookrightarrow$ Fluidos são o que chamamos de continuo, isso é, uma substância na qual suas características se mantém relativamente constantes, isso é, não há mudanças bruscas nas suas propriedades de um ponto a outro, possibilitando modela-lo através de equações diferenciais.

$\hookrightarrow$ Isso resulta, ainda, na constante deformação do fluido quando aplicada uma tensão de  cisalhamento, isso é, uma tensão tangente a superfície do fluido.

# Campo de Velocidade

$\hookrightarrow$ Quando falamos de velocidade de um fluido, por ser um continuo, precisamos falar de um campo de velocidade:

$$
\vec V = \vec V(x, y, z, t)
$$

$\hookrightarrow$ Onde temos que a velocidade depende do ponto no espaço (por isso $x, y, z$ ) assim como no tempo $t$.

$\hookrightarrow$ Além disso, temos que o vetor velocidade também pode ser escrito em termos de suas três componentes escalares:

$$
\vec V = u \hat i + v \hat j + w \hat k
$$

$\hookrightarrow$ Quando não há variação de qualquer propriedade com o  tempo (incluindo a velocidade) podemos afirmar que o fluido está em regime permanente:

$$
\frac{\partial \vec V}{\partial t} = 0 \therefore \vec V = \vec V (x, y, x)
$$

<aside>
<img src="Conceitos%20Fundamentais%20f3dc33f7913142868fbfc9791f3efaa5/yuru_camp.png" alt="Conceitos%20Fundamentais%20f3dc33f7913142868fbfc9791f3efaa5/yuru_camp.png" width="40px" /> IN A NUTSHELL → O campo de velocidade representa a velocidade do fluido que passa em qualquer lugar no espaço em um tempo $t$, e não representa UMA partícula específica.

</aside>

<aside>
<img src="Conceitos%20Fundamentais%20f3dc33f7913142868fbfc9791f3efaa5/Evangelion.gif" alt="Conceitos%20Fundamentais%20f3dc33f7913142868fbfc9791f3efaa5/Evangelion.gif" width="40px" /> OBS: Nós podemos ter que a velocidade depende de até 3 direções, dependendo se há $(x, y, z)$ na equação do campo de velocidade. Enquanto que nós podemos ter que o campo de escoamento é uni/bi/tri dimensionais a depender das componentes espaciais do campo, i.e $(\hat i, \hat j, \hat k)$.

</aside>

## Diferentes Tipos de Escoamento

$\hookrightarrow$ Nós somos capazes de classificar um escoamento como uni, bi, ou tridimensional dependendo do número de coordenadas espaciais necessárias para especificar seu campo de velocidade.

## Diferentes Visualizações

$\hookrightarrow$ No que tange a visualização do comportamento das partículas de um fluido nós temos as seguintes estratégias:

### Linha de Tempo

- Uma fotografia de todas as partículas em um espaço definido

### Linha de Trajetória

- Acompanha a trajetória de uma partícula ao longo do tempo

### Linha de Emissão

- Acompanha a trajetória de todas as partículas que passam por um espaço fixo no espaço

### Linha de Corrente

- Linhas desenhadas no campo de escoamento de modo que, em um dado instante são sempre tangentes à direção do escoamento.

### Representação Matemática

$\hookrightarrow$ Somo capazes de representar a linha de corrente através da seguinte equação:

$$
\frac{dy}{dx}\Big )_{particula} = \frac{v(x, y)}{u(x, y)}
$$

$\hookrightarrow$ Isso ocorre pois sabemos que a linha de corrente é tangente à direção de escoamento, que é dada pelas componentes da velocidade, que no caso de estudo é  $2D\therefore (v, x)$.

$\hookrightarrow$ Relembrando que temos $u$ como sendo a velocidade no eixo $x$ e $v$ como sendo a velocidade no eixo $y$:

$$
\begin{cases}
\frac{dx}{dt}\Big )_{particula} = u(x, y, t)\\
\frac{dy}{dt}\Big )_{particula} = v(x, y, t)
\end{cases}
$$

$\hookrightarrow$ Somos ainda capazes descobrir as equações paramétricas de trajetórias da partícula integrando as duas equações acima ($dx/dt$ e $dy/dt$), separando as variáveis e integrando o lado $x$ entre os limites $x_0$ e $x$ e o lado $t$ de $0$ até $t$, e de forma análoga na equação 2 que involve $y$ entre os limites de integração $y_0$ e $y$.

# Campo de Tensão

$\hookrightarrow$ Uma força $\partial \vec F$ que está sendo aplicada em um corpo fluido, em uma área $\partial \vec A$ pode ser descrita em duas componentes, uma normal e outra tangente à área, sendo elas a tensão normal $\sigma$ e a tensão cisalhante $\tau$:

$$
\begin{cases}
\sigma_n = \lim _{\delta \vec A \rightarrow 0} \frac{\delta \vec F_n}{\delta \vec A_n} \\ \\
\tau_n = \lim _{\delta \vec A \rightarrow 0} \frac{\delta \vec F_t}{\delta \vec A_n}
\end{cases}
$$

$\hookrightarrow$ Que podem ainda ser decompostas em:

$$
\tau_n \begin{cases}
\tau _{xy} =\lim _{\delta A_{x} \rightarrow 0} \frac{\delta F_y}{\delta A_x} \\ \\
\tau _{xz} =\lim _{\delta A_{z} \rightarrow 0} \frac{\delta F_z}{\delta A_x}
\end{cases}
$$

e 

$$
\sigma_{xx} = \lim _{\delta A_x \rightarrow 0} \frac{\delta F_x}{\delta A_x}
$$

![Screen Shot 2022-03-26 at 11.41.30 AM.png](Conceitos%20Fundamentais%20f3dc33f7913142868fbfc9791f3efaa5/Screen_Shot_2022-03-26_at_11.41.30_AM.png)

$\hookrightarrow$ Podemos então representar a tensão resultante em um ponto específico por:

![Screen Shot 2022-03-26 at 11.47.56 AM.png](Conceitos%20Fundamentais%20f3dc33f7913142868fbfc9791f3efaa5/Screen_Shot_2022-03-26_at_11.47.56_AM.png)

$$
\begin{bmatrix}
\sigma_{xx} & \tau_{xy} & \tau_{xz} \\ 

\tau_{yx} & \sigma_{yy}  & \tau_{yz} \\ 

\tau_{zx} & \tau_{zy} & \sigma_{zz}  \\ 
\end{bmatrix}
$$

# Viscosidade

$\hookrightarrow$ As tensões supracitadas são resultantes de viscosidade do fluido, descrita pela constante $\mu$, chamada de Viscosidade Absoluta ou Viscosidade Dinâmica.

$\hookrightarrow$ Com isso, temos que a tensão de cisalhamento para um fluido Newtoniano é dada por:

$$
\tau _{yx} = \mu \frac{du}{dy} = \mu \frac{V}{d}
$$

$\hookrightarrow$ Onde $\frac{du}{dy}$ é chamada de taxa de deformação ou taxa de cisalhamento. Também podendo ser expressa como $\frac{V}{d}$, isso é, a velocidade do objeto cisalhante e $d$ a altura da lâmina de fluido.

$\hookrightarrow$ Além disso temos que a viscosidade cinemática, dada por:

$$
v = \frac{\mu}{\rho}
$$

$\hookrightarrow$ Onde $\rho$ é a massa específica do fluido.