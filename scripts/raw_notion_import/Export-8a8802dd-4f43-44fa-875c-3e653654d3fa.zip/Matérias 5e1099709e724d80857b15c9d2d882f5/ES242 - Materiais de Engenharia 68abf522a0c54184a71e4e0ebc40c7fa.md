# ES242 - Materiais de Engenharia

Created: March 14, 2021 8:00 PM
Instituto: FEM
Semestre: 3º Semestre

[Anotações de Aula](ES242%20-%20Materiais%20de%20Engenharia%2068abf522a0c54184a71e4e0ebc40c7fa/Anotac%CC%A7o%CC%83es%20de%20Aula%20c7e61ca1c40f42b49a7dabba654994fd.csv)

---

[Anotações](ES242%20-%20Materiais%20de%20Engenharia%2068abf522a0c54184a71e4e0ebc40c7fa/Anotac%CC%A7o%CC%83es%204b551111f8bc455c92be06ef08a6997e.csv)

[Listas de Exercício ](ES242%20-%20Materiais%20de%20Engenharia%2068abf522a0c54184a71e4e0ebc40c7fa/Listas%20de%20Exerci%CC%81cio%20b28793e8f2f6460988d2950f588b9f13.csv)