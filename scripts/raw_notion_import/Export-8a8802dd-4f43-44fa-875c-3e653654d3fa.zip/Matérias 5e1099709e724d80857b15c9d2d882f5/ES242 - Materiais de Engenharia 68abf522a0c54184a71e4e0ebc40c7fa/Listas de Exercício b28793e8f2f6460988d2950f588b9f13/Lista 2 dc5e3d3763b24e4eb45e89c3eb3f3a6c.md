# Lista 2

Created: May 12, 2021 2:50 PM
Prova: P1
Tópicos: Diagramas de Fase

![Lista%202%20dc5e3d3763b24e4eb45e89c3eb3f3a6c/PHOTO-2021-05-10-20-31-52.jpg](Lista%202%20dc5e3d3763b24e4eb45e89c3eb3f3a6c/PHOTO-2021-05-10-20-31-52.jpg)