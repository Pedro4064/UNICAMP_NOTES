# Lista 4

Created: June 30, 2021 2:47 PM
Prova: P2
Tópicos: Deformação, Propriedades Mecânicas, Tensão

![Lista%204%204baf50b12cfd44d8994b2d4ac7c936ed/8d413a60-2da3-4c2e-b9b0-5275c8c073a8.jpg](Lista%204%204baf50b12cfd44d8994b2d4ac7c936ed/8d413a60-2da3-4c2e-b9b0-5275c8c073a8.jpg)

1. Os pontos mais importantes são:
    - Limite de Escoamento → Momento onde a deformação para de ser elástica e passa a ser permanente e plástica.
    - Limite de resistência de Tração → Início da queda de tensão.
2. São diferentes pois parece que, na tensão-deformação de engenharia, ocorre um amolecimento artificial, pois são consideradas somente as dimensões originais do corpor de prova na tensão de engenharia, o que deveria ocorrer é um aumento até a quebra na tensão real: 
    
    ![../Anotac%CC%A7o%CC%83es%204b551111f8bc455c92be06ef08a6997e/Propriedades%20Meca%CC%82nicas%20199395f9a9d74eba9a8c4c7aaad55c70/Screen_Shot_2021-06-10_at_9.23.14_PM.png](../Anotac%CC%A7o%CC%83es%204b551111f8bc455c92be06ef08a6997e/Propriedades%20Meca%CC%82nicas%20199395f9a9d74eba9a8c4c7aaad55c70/Screen_Shot_2021-06-10_at_9.23.14_PM.png)
    
3. Não seria possível pois o deslizamento  é facilitado por defeitos lineares (discordâncias), que são impossíveis de não existirem na prática.
4. A dureza é a resistência a riscos ou indentação por outros objetos, usada muitas das vezes como medição qualitativa da resistência mecânica.