# Lista 6

Created: June 30, 2021 4:01 PM
Prova: P2
Tópicos: Materiais Cerâmicos, Vidros

![Lista%206%20a6ec8f98bac6468a9bc79d4f9ca31ba1/607734e1-aa3d-4171-a28a-de1f34a8c5ae.jpg](Lista%206%20a6ec8f98bac6468a9bc79d4f9ca31ba1/607734e1-aa3d-4171-a28a-de1f34a8c5ae.jpg)

1. Materiais cerâmicos são frágeis devido as suas ligações, principalmente as iônicas,  pois quando uma energia suficientemente grande é aplicada ela é quebrada por completo, e não alongada ou distorcida, como em outras ligações.
2. Outra possibilidade para o processamento de cerâmicos que requerem geometrias mais complexas é a injeção.
3. A densidade dos sólidos nos estados amorfos se da pelo seu maior nível de desorganização ?
4. Um vidro é um produto metaestável que foi resfriado sem cristalização, já vitrocerâmicos tem por volta de $70\% - 90\%$ de cristalinos, obtidos através de tramanetos térmicos.