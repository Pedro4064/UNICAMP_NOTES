# F129 - Física Experimental

Created: March 14, 2021 7:58 PM
Instituto: IFGW
Semestre: 3º Semestre

[Tópicos](F129%20-%20Fi%CC%81sica%20Experimental%2012d130d9ea964236be97d31458cf47db/To%CC%81picos%20efb37b1c004546a0b05a3f6e96177665.csv)

[Tarefas](F129%20-%20Fi%CC%81sica%20Experimental%2012d130d9ea964236be97d31458cf47db/Tarefas%20e763eccd2ed5402caf8945a8f3088300.csv)