# Tabela de Integrais

Created: August 10, 2020 9:33 PM

![Tabela%20de%20Integrais%20d1714d6e6c79414ea715dbe35005737d/Screen_Shot_2020-08-14_at_10.31.10_AM.png](Tabela%20de%20Integrais%20d1714d6e6c79414ea715dbe35005737d/Screen_Shot_2020-08-14_at_10.31.10_AM.png)