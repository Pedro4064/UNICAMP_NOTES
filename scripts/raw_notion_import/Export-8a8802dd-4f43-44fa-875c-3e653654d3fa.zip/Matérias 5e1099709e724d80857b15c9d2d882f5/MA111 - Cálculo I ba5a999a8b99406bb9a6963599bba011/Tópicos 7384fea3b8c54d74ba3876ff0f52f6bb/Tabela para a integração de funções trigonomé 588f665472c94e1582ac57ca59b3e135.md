# Tabela para a integração de funções trigonométricas

Created: August 15, 2020 10:13 AM

![Tabela%20para%20a%20integrac%CC%A7a%CC%83o%20de%20func%CC%A7o%CC%83es%20trigonome%CC%81%20588f665472c94e1582ac57ca59b3e135/Screen_Shot_2020-08-15_at_10.14.51_AM.png](Tabela%20para%20a%20integrac%CC%A7a%CC%83o%20de%20func%CC%A7o%CC%83es%20trigonome%CC%81%20588f665472c94e1582ac57ca59b3e135/Screen_Shot_2020-08-15_at_10.14.51_AM.png)