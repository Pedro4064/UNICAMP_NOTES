# Translação em $t$ da transformada de Laplace

Aula: Aula 11
Created: April 28, 2021 9:47 PM
Prova: P1

![Translac%CC%A7a%CC%83o%20em%20$t$%20da%20transformada%20de%20Laplace%20d48831ada30c400b9d08ebe2dca94643/Screen_Shot_2021-04-28_at_9.47.39_PM.png](Translac%CC%A7a%CC%83o%20em%20$t$%20da%20transformada%20de%20Laplace%20d48831ada30c400b9d08ebe2dca94643/Screen_Shot_2021-04-28_at_9.47.39_PM.png)