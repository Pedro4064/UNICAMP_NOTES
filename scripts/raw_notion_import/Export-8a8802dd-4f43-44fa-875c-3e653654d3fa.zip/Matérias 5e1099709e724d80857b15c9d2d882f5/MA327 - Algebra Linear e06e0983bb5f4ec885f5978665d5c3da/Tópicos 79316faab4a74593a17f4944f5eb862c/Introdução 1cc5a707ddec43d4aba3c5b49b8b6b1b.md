# Introdução

Semana: Semana 1

![Introduc%CC%A7a%CC%83o%201cc5a707ddec43d4aba3c5b49b8b6b1b/Screen_Shot_2020-09-17_at_8.10.02_AM.png](Introduc%CC%A7a%CC%83o%201cc5a707ddec43d4aba3c5b49b8b6b1b/Screen_Shot_2020-09-17_at_8.10.02_AM.png)

  - Grupo de whatsapp - [https://chat.whatsapp.com/EB7obZohHGQ1Q0zakM971p](https://chat.whatsapp.com/EB7obZohHGQ1Q0zakM971p)