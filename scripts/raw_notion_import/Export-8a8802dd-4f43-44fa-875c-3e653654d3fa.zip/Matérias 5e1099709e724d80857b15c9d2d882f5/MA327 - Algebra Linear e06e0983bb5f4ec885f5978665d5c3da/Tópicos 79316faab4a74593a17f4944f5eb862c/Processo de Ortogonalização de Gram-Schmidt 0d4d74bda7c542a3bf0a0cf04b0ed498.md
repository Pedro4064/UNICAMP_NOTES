# Processo de Ortogonalização de Gram-Schmidt

Semana: Semana 12

- Basicamente, única coisa que precisamos lembrar é:
    
     A base antiga é composta por vetores $v_n$, e que a nova base ira ser constituída de vetores $w_n$, sendo que:
    
     
    
    $$
    w_1 = v_1
    $$
    
    E que:
    
    ![Processo%20de%20Ortogonalizac%CC%A7a%CC%83o%20de%20Gram-Schmidt%200d4d74bda7c542a3bf0a0cf04b0ed498/Screen_Shot_2020-11-22_at_3.47.14_PM.png](Processo%20de%20Ortogonalizac%CC%A7a%CC%83o%20de%20Gram-Schmidt%200d4d74bda7c542a3bf0a0cf04b0ed498/Screen_Shot_2020-11-22_at_3.47.14_PM.png)