# Boolean Arithmetic

Created: March 30, 2022 7:02 PM

[Anotações de Aula](Boolean%20Arithmetic%20bea2fd65d7824b61b3a56ffe8763be84/Anotac%CC%A7o%CC%83es%20de%20Aula%20613772694d384d06b8ee6f633d6dbfea.md)

- SUMMARY
    
    

# Números Binários

## Binário → Decimal

$\hookrightarrow$ Somos capazes de representar números da base 10 na base 2 (chamada de número binário).

$\hookrightarrow$ Por ser na base dois temos que os números são baseados em potências de dois. Mais especificamente baseados no índice do número (a.k.a do índice do bit) e seu valor, como mostrado abaixo:

$$
(10011)_{two} = 1 \cdot 2^4 + 0 \cdot 2^3 + 0 \cdot 2^2 + 1\cdot 2^1 + 1 \cdot 2^0 = 19
$$

$\hookrightarrow$ Onde começamos a contar o bit da direita para a esquerda, começando no índice $`0`$.

$\hookrightarrow$ Além disse chamamos o bit mais a esquerda de **Bit mais significativo**.

$\hookrightarrow$ De forma geral podemos transformar um número formado de uma string de $n$ dígitos em qualquer base $b$ para a base $10$ pela fórmula:

$$
(x_n \ x_{n-1} \ ... \ x_0)_b = \sum^n_{i=0} x_i \cdot b^i
$$

## Decimal → Binário

$\hookrightarrow$ Para passarmos de decimal para binário podemos fazer o seguinte:

![Untitled](Boolean%20Arithmetic%20bea2fd65d7824b61b3a56ffe8763be84/Untitled.png)

$\hookrightarrow$ Onde dividimos sucessivamente um número por dois até não conseguirmos mais e pegamos os remainders como os bits do nosso número em binário.

<aside>
<img src="Boolean%20Arithmetic%20bea2fd65d7824b61b3a56ffe8763be84/Evangelion.gif" alt="Boolean%20Arithmetic%20bea2fd65d7824b61b3a56ffe8763be84/Evangelion.gif" width="40px" /> OBS: Você considera o resultado da divisão como um bit somente no último

</aside>

# Adição de Números Binários

$\hookrightarrow$ A adição de binários é equivalente a adição de números decimais, a única diferença é que o carry se torna 1, como mostrado abaixo ao lado.

![Adição de dois números binários de 4 bits ](Boolean%20Arithmetic%20bea2fd65d7824b61b3a56ffe8763be84/Screen_Shot_2022-05-03_at_10.39.32_AM.png)

Adição de dois números binários de 4 bits 

![Adição de dois números de 4 bits com overflow](Boolean%20Arithmetic%20bea2fd65d7824b61b3a56ffe8763be84/Screen_Shot_2022-05-03_at_10.41.07_AM.png)

Adição de dois números de 4 bits com overflow

$\hookrightarrow$ A única real diferença é que como estamos lidando com computadores que possuem números limitados de bits para representar um número, dizemos que se o último carry (chamado de carry out) for igual a 1 ocorreu um overflow, pois precisaríamos de mais um bit para representar o resultado da soma mas nn temos, como mostrado ao lado.

# Complemento de Dois (Redix Complement)

$\hookrightarrow$ Algo muito importante é sermos capazes de representar números negativos.

$\hookrightarrow$ Nos computadores modernos nós utilizamos o método chamado de complemento de dois para representarmos números negativos.

$\hookrightarrow$ O complemento de dois de um número (i.e sua representação negativa) é dada por:

$$
-x = \bar x + 1
$$

$\hookrightarrow$ Onde $\bar x$ é o contrário do número $i.e$ negate $\therefore$ todo $1$ do número se torna $0$ e todo $0$ se torna $1$ (cada bit passa por um not basicamente) e somamos 1 (ao bit menos significativo).

$\hookrightarrow$ Com isso temos:

![Podemos observar que todos os números negativos começam com 1 e todos os positivos com 0](Boolean%20Arithmetic%20bea2fd65d7824b61b3a56ffe8763be84/Screen_Shot_2022-05-03_at_10.47.57_AM.png)

Podemos observar que todos os números negativos começam com 1 e todos os positivos com 0

<aside>
🧠 A melhor parte do complemento de dois é que para somar dois números, independente de serem ambos positivos, negativos ou um de cada é que podemos somar pelo método de adição em binário comum. Isso também implica que para subtração podemos simplesmente passar o segundo número por um circuito que o torna em complemento de dois e depois somamos.

</aside>