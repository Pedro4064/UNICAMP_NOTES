# Boolean Logic

Created: March 23, 2022 7:31 PM

[Anotações de Aula](Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Anotac%CC%A7o%CC%83es%20de%20Aula%20e082e6ea514e4ba6a2d9892b7a211079.md)

- SUMMARY

# Introdução

$\hookrightarrow$ Esse capítulo iremos explorar a Boolean Logic, que nada mais é do que as operações com variáveis do tipo booleans.

$\hookrightarrow$ Booleans nada mais são do que variáveis que só podem assumir o estado $1$ ou $0$ / $High$ ou $Low$.

$\hookrightarrow$ Podemos, ainda, representar números da base 10 (ou de qualquer base) somente através de valores boolenas (i.e $0\  ou \ 1$), o que é extremamente útil quando estamos tratando de representar números do cotidiano (base 10) em circuitos elétricos, que possuem somente valores $HIGH \therefore$ há tensão e $LOW \therefore$ não há tensão.

# Boolean Algebra

$\hookrightarrow$ Algebra boolean nada mais é do que funções que recebem como input valores boolean e que tem como output também valores boolean.

$\hookrightarrow$ Um subset de funções booleans especiais, que são chamadas de operadores, representam os blocos fundamentais para quaisquer outras funções boolean.

$\hookrightarrow$ Antes de apresentar elas, entretanto, precisamos introduzir mais um conceito, mais especificamente uma forma de visualizar/representar uma função/operador boolean, chamada de tabela verdade.

## Tabela Verdade

$\hookrightarrow$ A tabela verdade é composta por $n + 1$ colunas, sendo $n$ o número de inputs que nossa função e a última coluna o resultado obtido, como mostrada ao lado:

![Screen Shot 2022-05-02 at 5.37.39 PM.png](Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2022-05-02_at_5.37.39_PM.png)

## Operadores & Principais Funções

$\hookrightarrow$ Os principais Operadores são:

### AND

![Screen Shot 2022-05-02 at 5.43.29 PM.png](Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2022-05-02_at_5.43.29_PM.png)

### NOT

![Screen Shot 2022-05-02 at 5.43.38 PM.png](Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2022-05-02_at_5.43.38_PM.png)

### OR

![Screen Shot 2022-05-02 at 5.43.49 PM.png](Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2022-05-02_at_5.43.49_PM.png)

### XOR

![Screen Shot 2022-05-02 at 5.44.12 PM.png](Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2022-05-02_at_5.44.12_PM.png)

### NAND

![Screen Shot 2022-05-02 at 5.44.00 PM.png](Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2022-05-02_at_5.44.00_PM.png)

<aside>
<img src="Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Amazon_com__animal_shirt_women.jpeg" alt="Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Amazon_com__animal_shirt_women.jpeg" width="40px" /> Por Análise Combinatória (permutação) temos que existem $2^{2^n}$ funções booleanas para um conjunto de $n$ entradas. Isso vem do fato de que podemos permutar $n$ variáveis que possuem $2$ valores distintos em $2^n$ jeitos. Com isso teremos $2^n$ resultados que podem assumir $2$ valores distintos e que podem ser agrupados em  $2^{2^n}$ diferentes jeitos $\therefore$  esse é o nosso número de funções distintas.

</aside>

## Identidades Boolean

### Comutativa

$$
x \ And \ y = y \ And \ x
$$

### Associativa

$$
x \ And \ (y \ And \ z) = (x \ And \ y )\ And \ z 
$$

### Distributiva

$$
x \ And (y \ Or \ z) = (x \ And \ y) \ or \ (x \ And \ z)
$$

### De Morgan

$$
Not (x \ And \ z) = Not(x) \ or \ Not(z) \\ 

Not(x \ Or \ z) = Not(x) \ And \ Not(z)
$$

## Funções Boolean: Tabela Verdade → Fórmula

$\hookrightarrow$ Podemos representar qualquer função boolean por meio de uma fórmula composta somente por uma conjunto de $Or$, $And$ e $Not$'s.

$\hookrightarrow$ Podemos chegar nessa fórmula a partir da tabela verdade através de duas metodologias

### SOP - Sum of Products

- Nesse método nós pegamos todas as entradas da nossa tabela verdade que possui como resultado $1$, “multiplicamos” (i.e conectamos por $AND$'s) cada entrada dessa linha e depois somamos (i.e conectamos por $OR$'s ) as outras linhas que deram 1.

### POS - Product of Sums

- Ao contrário do SOP, no POS nós pegamos as entradas que tem como resultado $`0`$, somamos (i.e conectamos por $OR$'s) as entradas da linha e multiplicamos (i.e conectamos com $AND$'s ) as outras linhas.

<aside>
<img src="Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2021-09-23_at_10.18.50_PM.png" alt="Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2021-09-23_at_10.18.50_PM.png" width="40px" /> IMPORTANTE ressaltar que podemos simplificar botando em evidência combinações que se repetem e simplificando casos como $`y + \bar y`$ que sempre serão $1$ (OBS: $\bar y$ significa $Not(y)$)

</aside>

<aside>
<img src="Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2021-09-23_at_11.49.01_PM.png" alt="Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2021-09-23_at_11.49.01_PM.png" width="40px" /> IMPORTANTE também no que tange simplificação relembrar que podemos usar um termo mais de uma vez no equacionamento booleano → Isso nos ajuda a simplificar ao máximo através de combinação

</aside>

## NAND

$\hookrightarrow$ Algo a ser notado (principalmente se estivermos seguindo o $Nand2Tetris$) é o poder que a função NAND tem.

$\hookrightarrow$ Podemos Representar qualquer função boolean através de NANDs (inclusive os operadores básicos) Como vemos abaixo.

![Screen Shot 2022-05-02 at 7.44.52 PM.png](Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2022-05-02_at_7.44.52_PM.png)

## Logic Gates

$\hookrightarrow$ É importante sermos capazes de identificar os principais operadores em suas representações esquemáticas de logic Gates

![Screen Shot 2022-05-02 at 7.53.28 PM.png](Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2022-05-02_at_7.53.28_PM.png)

![Screen Shot 2022-05-02 at 7.53.52 PM.png](Boolean%20Logic%2063aa401efdd04db2a0b11302ad549e15/Screen_Shot_2022-05-02_at_7.53.52_PM.png)