# Anotações de Aula

## Possíveis Valores

$\hookrightarrow$ Para Aritmética boolean nossas variáveis são binárias, nós temos como possíveis valores $1$ e $0$, $True$ e $False$  etc.

## Possíveis Operadores

### AND

| $XY$ | $f()$ |
| --- | --- |
| $xy$ | 1 |
| $\bar x y$ | 0 |
| $x \bar y$ | 0 |
| $\bar x \bar y$ | 0 |

### OR

| $XY$ | $f()$ |
| --- | --- |
| $xy$ | 0 |
| $\bar x y$ | 1 |
| $x \bar y$ | 1 |
| $\bar x \bar y$ | 1 |

### NOT

| $X$ | $f()$ |
| --- | --- |
| $x$ | 0 |
| $\bar x $ | 0 |

### NOR

| $XY$ | $f()$ |
| --- | --- |
| $xy$ | 0 |
| $\bar x y$ | 0 |
| $x \bar y$ | 0 |
| $\bar x \bar y$ | 1 |

### NAND

| $XY$ | $f()$ |
| --- | --- |
| $xy$ | 0 |
| $\bar x y$ | 1 |
| $x \bar y$ | 1 |
| $\bar x \bar y$ | 1 |

### XOR

| $XY$ | $f()$ |
| --- | --- |
| $xy$ | 0 |
| $\bar x y$ | 1 |
| $x \bar y$ | 1 |
| $\bar x \bar y$ | 0 |

## Propriedades

$\hookrightarrow$ Dizemos que a lógica Boolean tem as seguintes propriedades:

### Comutatividade

$$
x \ And \ y = y \ And \ x
$$

### Associação

$$
X \ And (Y \ And \ Z) = (X \ And \  Y) \ And \ Z 
$$

### Distribuitiva

$$
X \ And \ (Y \ or \ Z) = (X \ And \ Y) or (X \ And \ Z)
$$

### Indepotente

$$
X \ and \ X = X
$$

$$
X \ or \ X = X
$$

### De Morgan

$$
\bar{X \cdot Y} = \bar X + \bar Y
$$

$$
\bar{X + Y} = \bar X \cdot \bar Y
$$

## Boolean Function a Partir da Tabela Verdade

### SOP - Soma de Produtos

$\hookrightarrow$ Terão vários `AND` conectados por `OR`

$\hookrightarrow$ A partir da tabela verdade você pega todas as combinações onde o resultado dá `1` e  junta eles com $ORs$

<aside>
🧠 Existem estratégias de otimização, sendo a principal delas botar em evidência as possíveis combinações que se repetem e simplificar casos como $`y+\bar y`$ que sempre serão $1$

</aside>

<aside>
🧠 Chamamos cada entrada (i.e cada linha da tabela verdade) é chamado de de "Mintermos”, e somos capazes de representar a função que descreve tal tabela como sendo $\sum m(1, 3, 5)$ onde os números dentro do parênteses é relativo ao Mintermo que tem como resultado $1$.

</aside>

### POS - Produto de Soma

$\hookrightarrow$ Ao contrário do SOP, nós pegaremos os termos onde tem valor de $`0`$, somos cada elemento da linha e multiplicamos pelas outras linhas que também possuem o valor de $0$

$\hookrightarrow$ Tais termos são chamados de Maxtermos

$\hookrightarrow$ A representação é dada por:

$$
f = \Pi M(0, 2, 4, 5)
$$

$\hookrightarrow$ Onde os números dentro do parênteses é referente aos Maxtermos (i.e termos que possuem o valor de $0$)