# Introdução

Created: March 23, 2022 7:31 PM

- SUMMARY

# Avaliações

$\hookrightarrow$ Teremos provas → Peso 6

$\hookrightarrow$ Atividades Práticas → Peso 4 mas nota mínima de $3.0$ para compor nota com as provas