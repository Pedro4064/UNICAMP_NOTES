# ME414 - Estatística para  Experimentalistas

Created: March 15, 2022 4:22 PM
Instituto: IMECC
Semestre: 5º Semestre

[Tópicos](ME414%20-%20Estati%CC%81stica%20para%20Experimentalistas%205b6066cd2e9942e69d9c9040e1b41af6/To%CC%81picos%20fd962c9a59e946798157549c8b364696.csv)