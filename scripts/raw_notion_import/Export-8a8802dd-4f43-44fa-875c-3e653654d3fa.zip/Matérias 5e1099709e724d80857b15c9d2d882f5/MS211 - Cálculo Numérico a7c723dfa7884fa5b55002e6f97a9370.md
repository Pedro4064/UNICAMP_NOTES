# MS211 - Cálculo Numérico

Created: August 9, 2021 7:48 PM
Instituto: IMECC
Semestre: 4º Semestre

[Tópicos](MS211%20-%20Ca%CC%81lculo%20Nume%CC%81rico%20a7c723dfa7884fa5b55002e6f97a9370/To%CC%81picos%20893c2601813f4782a557f84a4fe319c6.csv)