# Erros de Aproximação

Aula: Aula 02
Created: August 9, 2021 9:28 PM

[Anotações de Aula](Erros%20de%20Aproximac%CC%A7a%CC%83o%20a8524ad61b634e4a8dd47a09386ea8dc/Anotac%CC%A7o%CC%83es%20de%20Aula%20a1df27cefcd342059bcacb214f201d6c.md)