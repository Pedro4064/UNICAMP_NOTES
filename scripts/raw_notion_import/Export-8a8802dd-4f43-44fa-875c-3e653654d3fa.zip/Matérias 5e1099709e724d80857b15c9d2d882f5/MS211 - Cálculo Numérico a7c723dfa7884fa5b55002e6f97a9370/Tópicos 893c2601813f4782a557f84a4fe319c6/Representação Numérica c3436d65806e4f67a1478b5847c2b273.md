# Representação Numérica

Aula: Aula 01
Created: August 9, 2021 9:28 PM
Prova: P1

[Anotações de Aula](Representac%CC%A7a%CC%83o%20Nume%CC%81rica%20c3436d65806e4f67a1478b5847c2b273/Anotac%CC%A7o%CC%83es%20de%20Aula%20135307c712954e6d9339770d04825cb5.md)

# Anotações de Estudo