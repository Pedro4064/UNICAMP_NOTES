# Zeros da Função → Falsa Posição

Aula: Aula 04
Created: August 19, 2021 9:01 PM

[Anotações de Aula ](Zeros%20da%20Func%CC%A7a%CC%83o%20%E2%86%92%20Falsa%20Posic%CC%A7a%CC%83o%200fd7e59bc5a94caa801f9f78d263c228/Anotac%CC%A7o%CC%83es%20de%20Aula%2011ba3a0437c84cfcba506963f96b60d0.md)