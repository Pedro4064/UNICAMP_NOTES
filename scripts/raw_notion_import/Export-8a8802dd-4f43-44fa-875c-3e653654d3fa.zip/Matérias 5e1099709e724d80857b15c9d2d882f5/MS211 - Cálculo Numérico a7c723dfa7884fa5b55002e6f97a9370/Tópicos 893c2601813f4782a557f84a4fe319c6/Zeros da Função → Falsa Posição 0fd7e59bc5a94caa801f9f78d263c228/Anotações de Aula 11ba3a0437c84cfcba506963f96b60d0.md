# Anotações de Aula

# Método da Falsa Posição

- Análogo a como é o método da bisecção, mas nesse novo método, não dividimos o intervalo no meio.

## Método de Divisão

- Projetamos uma linha entre $a_k$ e $b_k$, e escolhemos o ponto de divisão $x_k$ o ponto que cruza a linha:

![Screen Shot 2021-08-19 at 9.04.21 PM.png](Anotac%CC%A7o%CC%83es%20de%20Aula%2011ba3a0437c84cfcba506963f96b60d0/Screen_Shot_2021-08-19_at_9.04.21_PM.png)

$$
x_k = \frac{a_k f(b_k) - b_k f(a_k)}{f(b_k) - f(a_k)}
$$