# Zeros da Função → Método Bissecção

Aula: Aula 03
Created: August 17, 2021 7:04 PM

[Anotações de Aula](Zeros%20da%20Func%CC%A7a%CC%83o%20%E2%86%92%20Me%CC%81todo%20Bissecc%CC%A7a%CC%83o%20a3ec748d81e64e289aedea37cf8d5447/Anotac%CC%A7o%CC%83es%20de%20Aula%20f5a1f4d27ef149a685d8a4e3df4174ec.md)