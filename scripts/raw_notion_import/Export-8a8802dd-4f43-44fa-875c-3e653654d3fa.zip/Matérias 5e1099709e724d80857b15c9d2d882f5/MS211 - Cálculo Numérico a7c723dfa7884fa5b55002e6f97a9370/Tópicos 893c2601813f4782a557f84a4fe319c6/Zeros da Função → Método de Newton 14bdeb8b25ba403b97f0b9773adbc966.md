# Zeros da Função → Método de Newton

Aula: Aula 05
Created: August 24, 2021 7:01 PM
Prova: P1

[Anotações de Aula](Zeros%20da%20Func%CC%A7a%CC%83o%20%E2%86%92%20Me%CC%81todo%20de%20Newton%2014bdeb8b25ba403b97f0b9773adbc966/Anotac%CC%A7o%CC%83es%20de%20Aula%203f14b35bd6804a18bccaee642e9060e1.md)