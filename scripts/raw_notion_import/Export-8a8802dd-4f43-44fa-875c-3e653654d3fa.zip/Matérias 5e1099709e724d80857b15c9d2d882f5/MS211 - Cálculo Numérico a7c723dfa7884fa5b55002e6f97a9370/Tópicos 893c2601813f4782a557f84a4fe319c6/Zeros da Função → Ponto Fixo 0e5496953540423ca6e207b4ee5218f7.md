# Zeros da Função → Ponto Fixo

Aula: Aula 04
Created: August 19, 2021 9:23 PM

[Anotações de Aula](Zeros%20da%20Func%CC%A7a%CC%83o%20%E2%86%92%20Ponto%20Fixo%200e5496953540423ca6e207b4ee5218f7/Anotac%CC%A7o%CC%83es%20de%20Aula%20cb8e6723517c40bb806ae9d367f80ff7.md)