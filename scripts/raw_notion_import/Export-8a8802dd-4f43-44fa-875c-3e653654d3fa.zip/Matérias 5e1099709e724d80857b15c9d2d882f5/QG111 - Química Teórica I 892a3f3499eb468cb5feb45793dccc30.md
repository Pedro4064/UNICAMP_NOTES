# QG111 - Química Teórica I

Created: August 8, 2020 1:55 AM
Instituto: IQ
Semestre: 1º Semestre

[Tópicos](QG111%20-%20Qui%CC%81mica%20Teo%CC%81rica%20I%20892a3f3499eb468cb5feb45793dccc30/To%CC%81picos%200452a92d3068424aae6ba43192a3de4b.csv)